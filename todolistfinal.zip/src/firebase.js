import  * as firebase from 'firebase';


// Initialize Firebase
var config = {
    apiKey: "AIzaSyClsabCwOeErrXuYHI8gG2yf-ep-7lax64",
    authDomain: "reactto-88cc9.firebaseapp.com",
    databaseURL: "https://reactto-88cc9.firebaseio.com",
    projectId: "reactto-88cc9",
    storageBucket: "reactto-88cc9.appspot.com",
    messagingSenderId: "239320360482"
  };
  firebase.initializeApp(config);
  


  export default  firebase;